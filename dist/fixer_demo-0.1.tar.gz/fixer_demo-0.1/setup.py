from setuptools import setup


setup(name='fixer_demo',
      version='0.1',
      description='Fixer service demo package',
      url='',
      author='Amir',
      author_email='a.h.mirshafiei@gmail.com',
      license='MIT',
      packages=['fixer'],
      zipsafe=False)